//
//  ViewController.swift
//  Hack_BeaconTec
//
//  Created by Glitch on 8/26/17.
//  Copyright © 2017 Glitch. All rights reserved.
//

import UIKit
import CoreLocation


class ViewController: UIViewController,CLLocationManagerDelegate  {
    
    let locationManager = CLLocationManager()
    let region = CLBeaconRegion(proximityUUID: NSUUID (uuidString:"B9407F30-F5F8-466E-AFF9-25556B57FE6D")! as UUID, identifier: "Beacon")
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        biblioteca.isEnabled = false
        rectoria.isEnabled = false
        ciap.isEnabled = false
        cb.isEnabled = false
        biblioteca.backgroundColor = .black
        rectoria.backgroundColor = .black
        ciap.backgroundColor = .black
        cb.backgroundColor = .black

        locationManager.delegate = self
        if (CLLocationManager.authorizationStatus() != CLAuthorizationStatus.authorizedWhenInUse){
            locationManager.requestWhenInUseAuthorization()
            
        }
        locationManager.startRangingBeacons(in: region)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
   
    @IBOutlet weak var cb: UIButton!
    @IBOutlet weak var ciap: UIButton!
    @IBOutlet weak var biblioteca: UIButton!
    @IBOutlet weak var rectoria: UIButton!
    
    func locationManager(_ manager: CLLocationManager, didRangeBeacons beacons: [CLBeacon], in region: CLBeaconRegion) {
        let knowBeacons = beacons.filter {$0.proximity != CLProximity.unknown}
        if (knowBeacons.count > 0) {
            let closestBeacon = knowBeacons[0] as CLBeacon
            if (closestBeacon.minor.intValue == 12345){
                biblioteca.isEnabled = true
                biblioteca.backgroundColor = .green
                
            }
            if (closestBeacon.minor.intValue == 21){
                rectoria.isEnabled = true
                rectoria.backgroundColor = .green

            }
            if (closestBeacon.minor.intValue == 42){
                ciap.isEnabled = true
                ciap.backgroundColor = .green
                
            }
            if (closestBeacon.minor.intValue == 28000){
                cb.isEnabled = true
                cb.backgroundColor = .green
                
            }


            
            
            
    
    }
    }
    }

