//
//  Rectoria.swift
//  Hack_BeaconTec
//
//  Created by Pato Saldivar on 27/08/17.
//  Copyright © 2017 Glitch. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit


class Rectoria: UIViewController {
    
    var playerController=AVPlayerViewController()
    var player: AVPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let videoString:String? = Bundle.main.path(forResource: "Video_Rectoria" , ofType: ".mp4")
        
        if let url =  videoString {
            
            let videoURL = NSURL(fileURLWithPath: url)
            self.player = AVPlayer(url: videoURL as URL)
            self.playerController.player = self.player
            
            
            
            
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func Video_Rectoria(_ sender: Any) {
        self.present(self.playerController, animated: true, completion: {
            
            self.playerController.player?.play()
            
            
        } )
    }


    
}
